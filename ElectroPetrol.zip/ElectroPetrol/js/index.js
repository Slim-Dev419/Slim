var petrol = new Vue({
    el: ".petrol",
    data: {
        active: false,
        price: 10,
        input: "",
        inputelectro: 0,
		street: "Вайнвуд Хіллз",
		fuel: 100,
		style: 0,
    },
    methods: {
		gostyle: function(index) {
			this.style = index
		},
        gov: function () {
            //console.log('повний')
            mp.trigger('electropetrol.gov')
        },
		full: function () {
            //console.log('повний')
            mp.trigger('electropetrol.full')
        },
        yes: function () {
            //console.log('так')
            mp.trigger('electropetrol', this.input)
        },
        no: function () {
            //console.log('ні')
            mp.trigger('closeElectroPetrol')
        },
        reset: function () {
            this.active = false
            this.input = ""
        }
    }
});

var petrol2 = new Vue({
    el: ".petrol2",
    data: {
        active: false,
        price: 12,
        input: "",
        inputelectro: 0,
		street: "Центральний район",
		fuel: 90,
		style: 0,
    },
    methods: {
		gostyle: function(index) {
			this.style = index
		},
        gov: function () {
            //console.log('повний')
            mp.trigger('electropetrol2.gov')
        },
		full: function () {
            //console.log('повний')
            mp.trigger('electropetrol2.full')
        },
        yes: function () {
            //console.log('так')
            mp.trigger('electropetrol2', this.input)
        },
        no: function () {
            //console.log('ні')
            mp.trigger('closeElectroPetrol2')
        },
        reset: function () {
            this.active = false
            this.input = ""
        }
    }
});

// Add more petrol stations as needed following the same pattern